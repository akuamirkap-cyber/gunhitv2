import type { ReactNode } from 'react';
import type { Save } from '../persist';
import { GameIcon } from './GameIcons';
import { Ico } from './FlatIcons';
import CoinSprite from './CoinSprite';
import DiamondSprite from './DiamondSprite';

function Page({ title, onBack, children }: { title: string; onBack(): void; children: ReactNode }) {
  return <div className="a in-bg absolute inset-0 z-40 flex flex-col overflow-hidden bg-[#07132f] px-3 pt-5 pb-3 text-white" style={{ background: 'radial-gradient(ellipse at 50% 0%, #244e88 0%, #0e264e 48%, #050a23 100%)' }}><header className="a in-down relative z-10 flex h-12 shrink-0 items-center gap-3"><button onClick={onBack} aria-label="Kembali" className="press grid h-11 w-11 place-items-center rounded-2xl border-2 border-[#7a4b00] bg-gradient-to-b from-[#ffe27a] to-[#f59e0b] shadow-[0_4px_0_#7a4b00]"><svg viewBox="0 0 24 24" className="h-7 w-7"><path d="M11 4 L3 12 L11 20 V15 H21 V9 H11 Z" fill="#fff" stroke="#7a4b00" strokeWidth="1.5" /></svg></button><h2 className="font-title text-2xl text-[#ffd23f] drop-shadow-[0_3px_0_#7a4b00]">{title}</h2></header><div className="relative mt-5 min-h-0 flex-1 overflow-auto">{children}</div></div>;
}
export function RankPage({ save, onBack }: { save: Save; onBack(): void }) {
  return <div data-page="ranks"><Page title="RANKS" onBack={onBack}><div className="font-title mb-4 flex items-center justify-center gap-2 text-[#ffd23f]"><Ico name="trophy" className="h-9 w-9" />BEST SCORE · {save.best}</div><p className="mb-4 text-center text-xs text-white/65">Riwayat run di perangkat ini · Level 1</p>{save.runs.length ? save.runs.map((r, i) => <div key={`${r.at}-${i}`} className="mb-2 flex items-center gap-3 rounded-2xl border-2 border-white/15 bg-black/25 p-3"><span className="font-title w-7 text-lg text-[#ffd23f]">{i + 1}</span><span className="flex-1"><span className="font-title block text-sm">PLAYER · PISTOL</span><span className="text-[10px] text-white/55">LEVEL 1 · {r.won ? 'CLEAR' : 'GAME OVER'}</span></span><span className="font-title text-2xl">{r.score}</span></div>) : <div className="rounded-2xl border-2 border-white/10 bg-black/20 p-6 text-center text-sm text-white/70">Belum ada run. Mainkan level 1!</div>}</Page></div>;
}
export function ReadyPage({ save, onBack, onClaim }: { save: Save; onBack(): void; onClaim(): void }) {
  const ready = save.clears > 0 && !save.rewardClaimed;
  return <div data-page="ready"><Page title="ACHIEVEMENT" onBack={onBack}><div className="a in-pop mx-auto mb-6 grid h-28 w-28 place-items-center rounded-full bg-white/5"><GameIcon name="gift" set="classic" className="h-24 w-24" /></div><section className="rounded-2xl border-2 border-[#4265a4] bg-gradient-to-b from-[#1e3a76] to-[#0c1d40] p-4 shadow-lg"><div className="font-title flex items-center gap-2 text-lg"><Ico name="target" className="h-8 w-8 text-[#ffb648]" />CLEAR LEVEL 1</div><p className="mt-2 text-xs text-white/70">Selesaikan level 1 dengan Pistol.</p><div className="mt-4 h-3 overflow-hidden rounded-full border border-black/50 bg-black/40"><div className="h-full rounded-full bg-gradient-to-r from-[#4ade80] to-[#a3e635]" style={{ width: save.clears > 0 ? '100%' : '0%' }} /></div><div className="font-title mt-2 text-right text-xs text-white/70">{save.clears > 0 ? 1 : 0}/1</div><button disabled={!ready} onClick={onClaim} className="press font-title mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-2xl border-2 border-[#7a4b00] bg-gradient-to-b from-[#ffe27a] to-[#f59e0b] text-[#633600] shadow-[0_4px_0_#7a4b00] disabled:opacity-40"><CoinSprite size={24} />{save.rewardClaimed ? 'DIKLAIM' : ready ? 'KLAIM · 20' : 'HADIAH · 20'}</button></section></Page></div>;
}
export function SettingsPage({ save, paused, onChange, onBack, onMenu }: { save: Save; paused: boolean; onChange(update: Partial<Save>): void; onBack(): void; onMenu(): void }) {
  const percent = Math.round(save.volume * 100);
  return (
    <div data-page={paused ? 'pause' : 'settings'} className="a in-fade absolute inset-0 z-[70] grid place-items-center px-5">
      <button type="button" aria-label="Tutup pengaturan" onClick={onBack} className="absolute inset-0 cursor-default bg-black/55 backdrop-blur-[2px]" />
      <section role="dialog" aria-modal="true" aria-labelledby="lite-settings-title" className="st-pop-in relative max-h-[94%] w-full max-w-[350px] overflow-y-auto rounded-[24px] border-2 border-white/15 p-3.5 text-white shadow-[0_20px_50px_rgba(0,0,0,.6),inset_0_1px_0_rgba(255,255,255,.14)]" style={{ background: 'linear-gradient(180deg, #17404af0 0%, #0e1519f5 45%, #080c0ff8 100%)' }}>
        <header className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-white/10"><GameIcon name="gear" set="flat" className="h-6 w-6" /></span>
          <div className="min-w-0 flex-1"><h2 id="lite-settings-title" className="font-title text-[20px] leading-none tracking-wide">{paused ? 'PAUSE' : 'PENGATURAN'}</h2><p className="font-title mt-1 text-[9px] tracking-[.14em] text-white/55">AUDIO · PERFECT SHOT LITE</p></div>
          <button type="button" onClick={onBack} aria-label="Kembali" className="press grid h-9 w-9 place-items-center rounded-xl border-2 border-white/20 bg-white/10 text-base">✕</button>
        </header>
        <section className="mt-3 rounded-2xl border border-white/10 bg-black/35 p-2.5">
          <div className="flex items-center gap-2.5">
            <button type="button" onClick={() => onChange({ sound: !save.sound })} aria-label="Suara" aria-pressed={save.sound} className="press grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-b from-[#38bdf8] to-[#0369a1] shadow-[0_3px_0_#0c4a6e]"><GameIcon name={save.sound ? 'sound' : 'mute'} set="flat" color="#fff" className="h-6 w-6" /></button>
            <div className="relative h-7 flex-1"><div className="absolute inset-x-0 top-1/2 h-2 -translate-y-1/2 rounded-full bg-black/50 shadow-inner" /><div className="absolute left-0 top-1/2 h-2 -translate-y-1/2 rounded-full bg-gradient-to-r from-[#22c55e] to-[#86efac] shadow-[0_0_8px_rgba(34,197,94,.55)]" style={{ width: `${percent}%` }} /><div className="pointer-events-none absolute top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2 rounded-full border-[3px] border-[#16a34a] bg-white shadow" style={{ left: `${percent}%` }} /><input type="range" min="0" max="100" step="1" value={percent} onChange={e => onChange({ volume: Number(e.target.value) / 100 })} aria-label="Volume suara" aria-valuetext={`${percent}%`} className="absolute inset-0 h-full w-full cursor-pointer opacity-0" /></div>
            <span className="font-title w-11 text-right text-[14px] text-[#86efac]">{percent}%</span>
          </div>
          <button type="button" onClick={() => onChange({ sound: !save.sound })} className="press font-title mt-2 flex h-9 w-full items-center justify-between rounded-xl bg-white/[.06] px-3 text-[12px]"><span>EFEK SUARA</span><span className={`relative h-5 w-9 rounded-full ${save.sound ? 'bg-[#3fdc72]' : 'bg-white/20'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow ${save.sound ? 'left-[18px]' : 'left-0.5'}`} /></span></button>
        </section>
        <section className="mt-3 rounded-2xl border border-white/10 bg-black/35 p-3"><h3 className="font-title text-xs text-[#ffd23f]">CARA MAIN</h3><p className="mt-2 text-[11px] leading-relaxed text-white/65">Ketuk layar atau tekan Spasi untuk menembak. Habiskan 5 peluru ke jeruk yang berputar. Jangan menabrak peluru yang sudah menancap. Escape untuk pause atau kembali.</p></section>
        <section className="mt-3 rounded-2xl border border-white/10 bg-black/35 p-3"><h3 className="font-title text-xs text-[#86efac]">PERFECT SHOT · LITE</h3><p className="mt-2 text-[11px] leading-relaxed text-white/65">Tampilan asli · Pistol saja · Level 1 saja. Progres Lite terpisah dan tidak mengubah data v1.</p></section>
        <section className="mt-3 rounded-2xl border border-amber-300/30 bg-amber-500/10 p-3">
          <h3 className="font-title flex items-center justify-between text-xs text-amber-300">
            <span>📦 UNDUH FILE V2 UTUH</span>
            <span className="text-[10px] text-amber-200/70">OFFLINE READY</span>
          </h3>
          <p className="mt-1.5 text-[11px] leading-relaxed text-white/75">
            Unduh seluruh file v2 (source code, aset gambar/suara, &amp; HTML standalone siap main tanpa server).
          </p>
          <div className="mt-2.5 flex flex-col gap-2">
            <a
              href="./perfect-shot-v2.zip"
              download="perfect-shot-v2.zip"
              className="press font-title flex h-10 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-b from-[#ffe27a] to-[#f59e0b] text-[12px] font-bold text-[#633600] shadow-[0_3px_0_#7a4b00]"
            >
              <span>⬇ UNDUH ZIP UTUH (371 KB)</span>
            </a>
            <a
              href="./perfect-shot-v2.html"
              download="perfect-shot-v2.html"
              className="press font-title flex h-9 w-full items-center justify-center gap-2 rounded-xl border border-sky-400/40 bg-sky-950/70 text-[11px] text-sky-200 shadow"
            >
              <span>🌐 UNDUH STANDALONE HTML (526 KB)</span>
            </a>
          </div>
        </section>
        {paused && <><button type="button" onClick={onBack} className="press shine font-title mt-4 h-12 w-full rounded-2xl bg-gradient-to-b from-[#4cef6a] to-[#18b93a] text-lg shadow-[0_4px_0_#0c7a22]">LANJUT</button><button type="button" onClick={onMenu} className="press font-title mt-3 h-10 w-full rounded-xl border-2 border-white/15 bg-white/10 text-sm">MENU</button></>}
      </section>
    </div>
  );
}

export function ResultPage({ won, score, coins, onReplay, onMenu, onQuest }: { won: boolean; score: number; coins: number; onReplay(): void; onMenu(): void; onQuest(): void }) {
  return <div data-page="result" data-result={won ? 'clear' : 'over'} className="a in-fade absolute inset-0 z-30 flex flex-col items-center justify-center bg-[#071421]/80 px-6 text-white backdrop-blur-sm"><h2 className="font-title text-center text-[42px] leading-tight text-[#ffd23f]" style={{ textShadow: '0 3px 0 #9c5a10,0 6px 0 #633600,0 10px 20px #000' }}>{won ? 'STAGE CLEAR!' : 'GAME OVER!'}</h2><p className="font-title mt-4 text-sm tracking-widest text-white/80">LEVEL 1</p>{won && <div className="my-5 flex gap-4">{[0, 1, 2].map(i => <Ico key={i} name="star" className="h-12 w-12 drop-shadow-[0_3px_0_#9c5a10]" color="#ffd23f" />)}</div>}<div className="mt-4 flex w-full justify-around rounded-2xl border-2 border-white/10 bg-black/30 p-5"><div className="text-center"><span className="text-xs text-white/60">SCORE</span><span className="font-title mt-1 block text-3xl">{score}</span></div><div className="text-center"><span className="text-xs text-white/60">COIN</span><span className="font-title mt-1 flex items-center gap-2 text-3xl text-[#ffd23f]"><CoinSprite size={28} />+{coins}</span></div></div><button data-action="replay" onClick={onReplay} className="press shine font-title mt-7 flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-b from-[#4cef6a] to-[#18b93a] text-xl shadow-[0_5px_0_#0c7a22]"><Ico name="replay" className="h-6 w-6" />ULANG LEVEL 1</button><div className="mt-4 flex w-full gap-3"><button onClick={onQuest} className="press font-title h-12 flex-1 rounded-2xl bg-gradient-to-b from-[#ff6a3d] to-[#e0331e] shadow-[0_4px_0_#9c1f12]">QUEST</button><button onClick={onMenu} className="press font-title h-12 flex-1 rounded-2xl border-2 border-white/20 bg-white/10">MENU</button></div><p className="mt-5 text-center text-xs text-white/50">Level 1 bisa dimainkan ulang. Tidak ada level lain di paket Lite.</p></div>;
}
